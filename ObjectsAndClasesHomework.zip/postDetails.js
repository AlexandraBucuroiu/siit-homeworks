class PostDetailsView {
    constructor() {
        const model = new PostModel();

        const queryParams = location.search.split('&');
        const postId = queryParams
            .find(param => param.includes('postId='))
            .split('=')[1];

        this.post = model.findById(postId);
    }

    async displayPost() {
        const article = document.querySelector('.js-post-details');
        article.append(await this.createHtml());
    }

    async createHtml() {
        const post = await this.post;

        const title = document.createElement('h2');
        title.innerHTML = post.title;

        const body = document.createElement('section');
        body.append(title);

        const image = document.createElement('img');
        image.src = post.imageUrl;
        body.append(image);

        const description = document.createElement('p');
        description.innerHTML = post.description;
        body.append(description);

        //butoane
        const newLine = document.createElement('p');

        const editBtn = document.createElement('button');
        editBtn.innerHTML = 'Edit';
        editBtn.classList.add('js-edit-button');
        editBtn.setAttribute('data-game-id', post._id);

        const deleteBtn = document.createElement('button');
        deleteBtn.innerHTML = 'Delete';
        deleteBtn.classList.add('js-delete-button');
        deleteBtn.setAttribute('data-game-id', post._id);

        newLine.append(editBtn, deleteBtn)

        body.append(newLine);


        return body;
    }
}

const view = new PostDetailsView();
view.displayPost();

function attachEventListeners() {
    document.addEventListener('click', handleClick);

    function handleClick(e) {
        const gameId = e.target.getAttribute('data-game-id');

        if (e.target.classList.contains('js-edit-button')) {
            handleEdit(gameId);
        } else if (e.target.classList.contains('js-delete-button')) {
            handleDelete(gameId);
        }
    }
}


function handleEdit(id) {
    fetch(`${apiUrl}/${id}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'title=Paul Test'
    })
        .then(res => res.json())
        .then(console.log)
}

function handleDelete(id) {
    fetch(`${apiUrl}/${id}`, {
        method: 'DELETE'
    })
        .then(res => res.json())
        .then(console.log);
}

