class PostListView {
    constructor() {
        const model = new PostModel();
        this.posts = model.getAll();
    }

    async createPostList() {
        const fragment = document.createDocumentFragment();

        for (const post of await this.posts) {
            const postHtml = this.createPostHtml(post);
            fragment.append(postHtml);
        }

        document.querySelector('.js-post-list').append(fragment);
    }

    createPostHtml(post) {
        const p = document.createElement('p');
        const a = document.createElement('a');
        a.innerHTML = post.title;
        a.href = 'details.html?postId=' + post._id;
        //a.target = '_blank';

        p.append(a);

        return p;
    }
}

const view = new PostListView();

view.createPostList();